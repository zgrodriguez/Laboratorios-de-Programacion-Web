# Portfolio personal — Laboratorio 2

## Descripción

Este proyecto consiste en la aplicación de estilos CSS3 a un portfolio personal desarrollado previamente con HTML5. Se busca mejorar su apariencia visual, organización, legibilidad y adaptación a diferentes tamaños de pantalla.

## Objetivos

- Aplicar los conocimientos adquiridos sobre CSS3.
- Separar la presentación del contenido mediante una hoja de estilos externa.
- Utilizar selectores, propiedades y reglas CSS para diseñar los elementos de las páginas.
- Implementar un diseño adaptable a dispositivos móviles, tabletas y computadoras.
- Mejorar la experiencia de navegación y la presentación del contenido.

## Tecnologías utilizadas

- HTML5.
- CSS3.
- Google Fonts.

## Características implementadas

- Hoja de estilos externa (`styles.css`).
- Organización visual de las secciones y los elementos de las páginas.
- Diseño adaptable mediante media queries.
- Uso de Flexbox y CSS Grid.
- Efectos de interacción para enlaces y botones.
- Adaptación de imágenes, vídeos, tablas y formularios.
- Soporte para preferencias de colores del sistema mediante modo oscuro.

## Visualización del proyecto

Para visualizar el sitio web:

1. Descargar o descomprimir la carpeta del proyecto.
2. Abrir la carpeta en Visual Studio Code.
3. Iniciar un servidor local, por ejemplo, mediante Live Server.
4. Abrir `index.html` en el navegador.

## Autora

Zailenys García Rodríguez

Carrera: Ingeniería Informática.

Universidad Central Marta Abreu de Las Villas (UCLV).