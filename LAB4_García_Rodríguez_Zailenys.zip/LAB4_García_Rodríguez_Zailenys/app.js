const resultados = document.getElementById("resultados");
const busqueda = document.getElementById("busqueda");
const filtroGenero = document.getElementById("filtro-genero");

let series = [];

const cargarSeries = async () => {
    try {
        const respuesta = await fetch("data.json");

        if (!respuesta.ok) {
            throw new Error("No se pudieron cargar los datos.");
        }

        series = await respuesta.json();

        mostrarSeries(series);

    } catch (error) {
        resultados.textContent = "Error al cargar las series. Inténtalo nuevamente.";
        console.error("Error:", error);
    }
};

const mostrarSeries = (lista) => {
    resultados.textContent = "";

    if (lista.length === 0) {
        resultados.textContent = "No se encontraron series.";
        return;
    }

    lista.forEach((serie) => {
        const tarjeta = document.createElement("article");
        tarjeta.classList.add("serie");

        const imagen = document.createElement("img");
        imagen.src = `img/${serie.imagen}`;
        imagen.alt = `Póster de ${serie.titulo}`;
        imagen.loading = "lazy";

        const titulo = document.createElement("h3");
        titulo.textContent = serie.titulo;

        const anio = document.createElement("p");
        anio.textContent = `Año: ${serie.anio}`;

        const genero = document.createElement("p");
        genero.textContent = `Género: ${serie.genero}`;

        const episodios = document.createElement("p");
        episodios.textContent = `Episodios: ${serie.episodios}`;

        const plataforma = document.createElement("p");
        plataforma.textContent = `Plataforma: ${serie.plataforma}`;

        tarjeta.append(
            imagen,
            titulo,
            anio,
            genero,
            episodios,
            plataforma
        );

        resultados.appendChild(tarjeta);
    });
};

const filtrarSeries = () => {
    const texto = busqueda.value.toLowerCase().trim();
    const generoSeleccionado = filtroGenero.value;

    const seriesFiltradas = series.filter((serie) => {
        const coincideTitulo = serie.titulo.toLowerCase().includes(texto);

        const coincideGenero = generoSeleccionado === "" ||
            serie.genero === generoSeleccionado;

        return coincideTitulo && coincideGenero;
    });

    mostrarSeries(seriesFiltradas);
};

busqueda.addEventListener("input", filtrarSeries);
filtroGenero.addEventListener("change", filtrarSeries);

cargarSeries();
