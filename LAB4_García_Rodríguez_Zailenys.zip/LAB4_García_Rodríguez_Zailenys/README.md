# K-Drama World

## Descripción del proyecto

K-Drama World es una aplicación web que permite explorar un catálogo de series coreanas (K-Dramas). Presenta información de cada serie mediante tarjetas dinámicas y ofrece herramientas para buscar títulos y filtrar por género.

## Objetivo

Desarrollar una aplicación web utilizando JavaScript nativo que permita cargar y mostrar información almacenada en un archivo JSON, incorporando funcionalidades de búsqueda y filtrado dinámico.

## Funcionalidades

- Visualización dinámica de un catálogo de 10 series coreanas.
- Búsqueda de series por título.
- Filtrado de series por género.
- Combinación de búsqueda y filtros.
- Visualización de información como año de estreno, género, número de episodios y plataforma.
- Mensaje cuando no se encuentran resultados.
- Diseño adaptable a ordenadores, tabletas y dispositivos móviles.
- Manejo de errores durante la carga de los datos.

## Tecnologías utilizadas

- **HTML5:** estructura y organización del contenido.
- **CSS3:** diseño visual, estilos y adaptación a diferentes tamaños de pantalla.
- **JavaScript:** carga de datos, búsqueda, filtrado y generación dinámica de tarjetas.
- **JSON:** almacenamiento de la información de las series.

No se utilizan frameworks ni bibliotecas externas de JavaScript.

## Estructura del proyecto

LAB4_García_Rodríguez_Zailenys/
│
├── index.html
├── styles.css
├── app.js
├── data.json
├── README.md
│
└── img/
    ├── logo.png
    ├── fondo-kdramas.jpg
    └── [imágenes de las series]
```

## Instrucciones de ejecución

1. Descargar o descomprimir la carpeta del proyecto.
2. Abrir la carpeta en Visual Studio Code.
3. Instalar la extensión Live Server, si todavía no está instalada.
4. Abrir el archivo `index.html`.
5. Hacer clic derecho y seleccionar **Open with Live Server**.
6. La aplicación se abrirá en el navegador.

**Nota:** Se recomienda utilizar Live Server para ejecutar el proyecto, ya que la aplicación utiliza `fetch()` para cargar los datos del archivo `data.json`.

## Autoría

Zailenys García Rodríguez