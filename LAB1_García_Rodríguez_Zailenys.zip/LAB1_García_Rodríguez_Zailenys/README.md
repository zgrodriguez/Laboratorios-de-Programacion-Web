# Portfolio personal — Laboratorio 1

## Descripción

Este proyecto consiste en el desarrollo de un portfolio personal utilizando HTML5. Su propósito es presentar información académica y personal, mostrar los proyectos realizados y ofrecer medios de contacto.

## Objetivos

- Aplicar los conocimientos adquiridos sobre HTML5.
- Organizar el contenido mediante una estructura semántica.
- Crear páginas web interconectadas mediante enlaces de navegación.
- Presentar información personal, académica y profesional de forma organizada.

## Tecnologías utilizadas

- HTML5.

## Contenido del sitio web

El portfolio está organizado en las siguientes páginas:

- **Inicio:** presentación personal e información académica.
- **Proyectos:** descripción y presentación de proyectos realizados.
- **Currículum:** formación académica, habilidades y conocimientos.
- **Contacto:** información y formulario de contacto.
- **Aviso legal:** información legal del sitio web.

## Visualización del proyecto

Para visualizar el sitio web:

1. Descargar o descomprimir la carpeta del proyecto.
2. Abrir la carpeta en Visual Studio Code o en el explorador de archivos.
3. Abrir el archivo `index.html` en un navegador web.

## Autora

Zailenys García Rodríguez

Carrera: Ingeniería Informática.

Universidad Central Marta Abreu de Las Villas (UCLV).